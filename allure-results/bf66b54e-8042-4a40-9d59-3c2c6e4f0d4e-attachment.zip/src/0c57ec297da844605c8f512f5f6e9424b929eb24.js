const {test, expect} = require('@playwright/test')

test("Select Values From Dropdown", async function({page}){
    await page.goto("https://freelance-learn-automation.vercel.app/signup")

    await page.locator("#state").selectOption({label:"Goa"})

    await expect(page.locator("#state")).toHaveValue("Goa")
    console.log("Selected state:", await page.locator("#state").inputValue())

    //await page.waitForTimeout(1000)

    await page.locator("#state").selectOption({value:"Himachal Pradesh"})

   // await page.waitForTimeout(1000)

    await page.locator("#state").selectOption({index:3})

    // await page.waitForTimeout(3000)

    /*  const value = await page.locator("#state").textContent()

     console.log("All dropdown values "+value)

     await expect(value.includes("Kerala")).toBeTruthy()

     */

     let state = await page.$("#state")

     let allElements = await state.$$(("option"))

     let ddStatus = false

     for(let i=0; i<=allElements.length; i++)
     {
        let element = allElements[i]

        let value = await element.textContent()

        if(value.includes("Rajasthan"))
        {
            ddStatus = true
            break
        }

        console.log("Value from dropdown using for loop "+value)
     }
     await expect(ddStatus).toBeTruthy()
})